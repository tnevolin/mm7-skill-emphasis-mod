-- configure shrine event
configureShrineEvent(261, 0, "BaseMight", 14, 15, 16, 17)

