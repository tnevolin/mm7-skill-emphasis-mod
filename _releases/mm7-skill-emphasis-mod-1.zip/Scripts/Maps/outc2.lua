-- configure shrine event
configureShrineEvent(261, 4, "BaseAccuracy", 11, 12, 13, 14)

