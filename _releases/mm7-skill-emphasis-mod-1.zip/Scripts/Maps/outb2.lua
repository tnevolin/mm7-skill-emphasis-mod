-- configure shrine event
configureShrineEvent(261, 11, "MagicResistance", 18, 19, 20, 21)

